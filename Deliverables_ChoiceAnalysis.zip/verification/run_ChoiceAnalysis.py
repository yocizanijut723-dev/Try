"""实际原始数据的独立核验/输出；MATLAB 主入口为 analyze_ChoiceAnalysis.m。
Python 需要 numpy/scipy/pandas/matplotlib。本模块读取此次数据的 MCOS table
布局并严格核查名称/引用；不用于未知采集文件或模拟数据。
"""
from pathlib import Path
import sys, itertools, hashlib
import numpy as np
import pandas as pd
import scipy.io as sio
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from inspect_ChoiceAnalysis import cells,table
ROOT=Path(__file__).resolve().parent
if ROOT.name=='verification': ROOT=ROOT.parent
OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
frames=[];configs=[];sources=[]
for s in [3,4,5]:
    for b in range(1,5):
        fn=ROOT/'data'/f'Subject{s}'/f'Subject{s}_block{b}.mat'
        a=cells(str(fn));t=table(a,21,26);cfg=table(a,7,12)
        assert cfg['subjectID'][0]==f'Subject{s}' and cfg['currentBlock'][0]==b
        df=pd.DataFrame({k:v for k,v in t.items() if k not in ['leftTrajectory','rightTrajectory']})
        df['SubjectID']=s;df['Block']=b
        H={'左手','右手'};T={'左目标','右目标'}
        def cond(r):
            q1,q2=r.cue1,r.cue2
            if q1 in H and q2 in T:return 1
            if q1 in T and q2 in H:return 2
            if q1 in H and q2=='自由目标':return 3
            if q1 in T and q2=='自由手':return 4
            if q1=='自由目标' and q2 in H:return 5
            if q1=='自由手' and q2 in T:return 6
            if (q1,q2)==('自由手','自由目标'):return 7
            if (q1,q2)==('自由目标','自由手'):return 8
            raise ValueError('Unknown cue combination')
        df['Condition']=df.apply(cond,axis=1)
        instructedH=df.cue1.isin(H)|df.cue2.isin(H);instructedT=df.cue1.isin(T)|df.cue2.isin(T)
        known=df.responseHand.isin(H)&df.responseTarget.isin(T)
        correct=(~instructedH|df.handCorrect.eq(1))&(~instructedT|df.targetCorrect.eq(1))
        df['AnalysisValid']=df.trialValid.eq(1)&known&correct&df.bothMoved.eq(0)
        assert (df.trialValid.eq(1)==df.AnalysisValid).all()
        assert df.loc[~instructedH,'handCorrect'].isna().all()
        assert df.loc[~instructedT,'targetCorrect'].isna().all()
        for _,d in df.groupby('plannedTrial'):
            assert d.cue1.nunique()==d.cue2.nunique()==1
            assert d.attemptNumber.nunique()==len(d)
        v=df[df.AnalysisValid];assert not v.plannedTrial.duplicated().any()
        assert df.plannedTrial.nunique()==int(cfg['nTrials'][0])==100
        assert (df.cue1Onset.lt(df.cue2Onset)&df.cue2Onset.lt(df.goOnset)).all()
        for _,r in v.iterrows():
            if instructedH.loc[r.name]:
                specified=r.cue1 if r.cue1 in H else r.cue2
                assert r.responseHand==specified
            if instructedT.loc[r.name]:
                specified=r.cue1 if r.cue1 in T else r.cue2
                assert r.responseTarget==specified
            prefix='left' if r.responseHand=='左手' else 'right'
            xx=r[prefix+'ReleaseX'];yy=r[prefix+'ReleaseY']
            tx=cfg['screenWidthPx'][0]/2+(-1 if r.responseTarget=='左目标' else 1)*cfg['targetOffsetXPx'][0]
            ty=cfg['screenHeightPx'][0]/2-cfg['targetOffsetYPx'][0]
            assert np.hypot(xx-tx,yy-ty)<=cfg['targetResponseRadiusPx'][0]+1e-6
        frames.append(df);sources.append({'File':str(fn.relative_to(ROOT)),'SHA256':hashlib.sha256(fn.read_bytes()).hexdigest()})
        configs.append({k:cfg[k][0] for k in ['subjectID','version','currentBlock','targetOffsetXPx','targetOffsetYPx','screenWidthPx','screenHeightPx','targetResponseRadiusPx']})
x=pd.concat(frames,ignore_index=True);valid=x[x.AnalysisValid]
counts=[];sides=[]
for (s,c),d in x.groupby(['SubjectID','Condition']):
    v=d[d.AnalysisValid];planned=len(d[['Block','plannedTrial']].drop_duplicates());assert planned==([80,80]+[40]*6)[c-1]
    counts.append(dict(SubjectID=s,Condition=f'C{c}',RawAttempts=len(d),InitialAttempts=int(d.attemptNumber.eq(1).sum()),UniquePlannedTrials=planned,RecordedValidAttempts=int(d.trialValid.eq(1).sum()),ValidTrials=len(v),ExcludedAttempts=len(d)-len(v),InconsistentValidFlags=0,MissingResponseAttempts=int((~(d.responseHand.isin(H)&d.responseTarget.isin(T))).sum())))
    sides.append(dict(SubjectID=s,Condition=f'C{c}',ValidLeftHand=int(v.responseHand.eq('左手').sum()),ValidRightHand=int(v.responseHand.eq('右手').sum()),ValidLeftTarget=int(v.responseTarget.eq('左目标').sum()),ValidRightTarget=int(v.responseTarget.eq('右目标').sum()),RawInstructedLeftHand=int((d.cue1.eq('左手')|d.cue2.eq('左手')).sum()),RawInstructedRightHand=int((d.cue1.eq('右手')|d.cue2.eq('右手')).sum()),RawInstructedLeftTarget=int((d.cue1.eq('左目标')|d.cue2.eq('左目标')).sum()),RawInstructedRightTarget=int((d.cue1.eq('右目标')|d.cue2.eq('右目标')).sum())))
labels=['P(LT|LH)','P(LT|RH)','P(LH|LT)','P(LH|RT)'];fixed=['Left Hand','Right Hand','Left Target','Right Target'];conditions=[[3,7],[3,7],[4,8],[4,8]]
P=np.full((3,4,2),np.nan);N=np.zeros_like(P,dtype=int);D=np.zeros_like(P,dtype=int);rows=[]
for si,s in enumerate([3,4,5]):
    for pi in range(4):
        for mi,c in enumerate(conditions[pi]):
            d=valid[(valid.SubjectID==s)&(valid.Condition==c)]
            field='responseHand' if pi<2 else 'responseTarget';side=['左手','右手','左目标','右目标'][pi]
            d=d[d[field]==side];dep='responseTarget' if pi<2 else 'responseHand';left='左目标' if pi<2 else '左手'
            den=len(d);num=int(d[dep].eq(left).sum());prob=num/den if den else np.nan
            P[si,pi,mi]=prob;N[si,pi,mi]=num;D[si,pi,mi]=den
            rows.append(dict(SubjectID=s,Panel='abcd'[pi],Condition=f'C{c}',FirstCue='Hand' if pi<2 else 'Target',FirstCueMode=['Instructed','Free'][mi],FixedFirstChoice=fixed[pi],ProbabilityLabel=labels[pi],ConditionalProbability=prob,Numerator=num,Denominator=den))
def desc(a):
    a=np.asarray(a);a=a[np.isfinite(a)];n=len(a)
    return (np.mean(a) if n else np.nan,np.std(a,ddof=1) if n>1 else np.nan,np.std(a,ddof=1)/np.sqrt(n) if n>1 else np.nan,n)
groups=[];diffrows=[];stats=[]
for pi in range(4):
    for mi,c in enumerate(conditions[pi]):
        mu,sd,se,n=desc(P[:,pi,mi]);groups.append(dict(Panel='abcd'[pi],Condition=f'C{c}',ProbabilityLabel=labels[pi],FirstCueMode=['Instructed','Free'][mi],NSubjects=n,Mean=mu,SD=sd,SEM=se,TotalDenominatorAuditOnly=int(D[:,pi,mi].sum())))
    differences=P[:,pi,1]-P[:,pi,0];d=differences[np.isfinite(differences)];mu,sd,se,n=desc(d)
    for si,s in enumerate([3,4,5]):diffrows.append(dict(SubjectID=s,Panel='abcd'[pi],ProbabilityLabel=labels[pi],InstructedCondition=f'C{conditions[pi][0]}',FreeCondition=f'C{conditions[pi][1]}',InstructedProbability=P[si,pi,0],FreeProbability=P[si,pi,1],DifferenceFreeMinusInstructed=differences[si]))
    flips=np.array([abs(np.mean(d*np.array(sign))) for sign in itertools.product([-1,1],repeat=n)]) if n else np.array([])
    p=float(np.mean(flips>=abs(mu)-1e-12)) if n else np.nan
    stats.append(dict(Panel='abcd'[pi],ProbabilityLabel=labels[pi],NPairedSubjects=n,MeanDifference=mu,SDDifference=sd,SEMDifference=se,MedianDifference=np.median(d),MinDifference=min(d),MaxDifference=max(d),NPositive=int(sum(d>0)),NNegative=int(sum(d<0)),NZero=int(sum(d==0)),ExactTwoSidedP=p,NFlips=len(flips)))
statdf=pd.DataFrame(stats);p=statdf.ExactTwoSidedP.to_numpy();idx=np.argsort(p);adj=np.empty(4);adj[idx]=np.minimum(1,np.maximum.accumulate(p[idx]*np.arange(4,0,-1)));statdf['HolmAdjustedP']=adj
framesout={'TrialCounts':pd.DataFrame(counts),'SideCounts':pd.DataFrame(sides),'IndividualProbabilities':pd.DataFrame(rows),'GroupProbabilities':pd.DataFrame(groups),'PairedDifferences':pd.DataFrame(diffrows),'Statistics':statdf,'TrialAudit':x,'ConfigurationAudit':pd.DataFrame(configs),'SourceHashes':pd.DataFrame(sources)}
for name,df in framesout.items():df.to_csv(OUT/(name+'_ChoiceAnalysis.csv'),index=False,encoding='utf-8-sig')
def matstruct(df):
    return {k:np.array([str(v) for v in df[k]],dtype=object).reshape(-1,1) if df[k].dtype==object else df[k].to_numpy().reshape(-1,1) for k in df.columns}
sio.savemat(OUT/'Results_ChoiceAnalysis.mat',{'results':dict(P=P,numerator=N,denominator=D,subjects=np.array([3,4,5]),counts=matstruct(framesout['TrialCounts']),probabilities=matstruct(framesout['IndividualProbabilities']),group=matstruct(framesout['GroupProbabilities']),differences=matstruct(framesout['PairedDifferences']),statistics=matstruct(statdf),sideCounts=matstruct(framesout['SideCounts']),differenceDirection='Free minus Instructed',executionEngine='Python independent computation from original MAT MCOS tables; MATLAB entry point not executed',inferenceAssumption='Independent subjects; paired differences sign-exchangeable under null; full two-sided enumeration; Holm over 4 comparisons')},do_compression=True)
bar_rgb=np.array([116,175,219])/255
point_rgb=.65*np.ones(3)+.35*bar_rgb
line_rgb=.45*np.ones(3)+.55*bar_rgb
offsets=np.array([-.08,.02,.10])
fig,axs=plt.subplots(2,2,figsize=(11,7.6))
means=np.nanmean(P,axis=0);sems=np.nanstd(P,axis=0,ddof=1)/np.sqrt(np.isfinite(P).sum(axis=0))
for pi,ax in enumerate(axs.flat):
    ax.bar([1,2],means[pi],width=.58,color=bar_rgb,edgecolor='none',zorder=1)
    ax.errorbar([1,2],means[pi],yerr=sems[pi],fmt='none',color=[.30,.36,.40],lw=1.1,capsize=3.5,zorder=2)
    for si in range(3):
        ax.plot(np.array([1,2])+offsets[si],P[si,pi],'-o',color=line_rgb,lw=.85,ms=7,mfc=point_rgb,mec=line_rgb,zorder=3,clip_on=False)
    ax.set(xlim=(.55,2.45),ylim=(0,1),xticks=[1,2],xticklabels=['First Cue Instructed','First Cue Free'],yticks=np.arange(0,1.01,.2),ylabel='Conditional probability')
    ax.set_title(labels[pi],fontsize=14,pad=14)
    ax.spines[['top','right']].set_visible(False)
    for spine in ['bottom','left']:ax.spines[spine].set_color('.3');ax.spines[spine].set_linewidth(.8)
    ax.tick_params(direction='out',labelsize=10,colors='.25')
    ax.yaxis.label.set_color('.25')
fig.tight_layout(pad=2.5,h_pad=3.2,w_pad=3)
fig.savefig(OUT/'Figure_ChoiceAnalysis.png',dpi=300)
fig.savefig(OUT/'Figure_ChoiceAnalysis.svg');plt.close(fig)
# 写入 MATLAB 传统 HG figure 容器：线、点、误差线和文字均可编辑。
# hgS_070000 是 MATLAB FIG 的图形树变量；原生 savefig 路径由 .m 文件提供。
# 当前环境无 MATLAB，无法执行 openfig 验证；此限制在 README 中注明。
dtype=[('type','O'),('handle','O'),('properties','O'),('children','O'),('special','O')]
handle=0
def hg(kind,props,children=None):
    global handle
    handle+=1;a=np.empty((1,1),dtype=dtype)
    a['type'][0,0]=kind;a['handle'][0,0]=float(handle);a['properties'][0,0]=props
    a['children'][0,0]=np.concatenate(children,axis=1) if children else np.empty((0,0),dtype=dtype)
    a['special'][0,0]=np.empty((0,0));return a
def line(xx,yy,color,lw=1,marker='none',size=6,fill='none'):
    return hg('line',dict(XData=np.array(xx,dtype=float),YData=np.array(yy,dtype=float),Color=np.array(color),LineStyle='-',LineWidth=lw,Marker=marker,MarkerSize=size,MarkerFaceColor=fill,MarkerEdgeColor=np.array(color),Visible='on'))
def text(xx,yy,txt,size=10,rotation=0,align='center'):
    return hg('text',dict(Position=np.array([xx,yy,0.]),String=txt,FontName='Arial',FontSize=size,Color=np.array([0.,0.,0.]),Rotation=rotation,HorizontalAlignment=align,VerticalAlignment='middle',Interpreter='none',Clipping='off',Visible='on'))
axes=[]
for pi in range(4):
    children=[]
    for mi in range(2):
        xx=mi+1.;yy=means[pi,mi];se=sems[pi,mi]
        children.append(hg('patch',dict(XData=np.array([xx-.29,xx+.29,xx+.29,xx-.29]),YData=np.array([0.,0.,yy,yy]),FaceColor=bar_rgb,EdgeColor='none',Visible='on')))
        children.extend([line([xx,xx],[yy-se,yy+se],[.30,.36,.40],1.1),line([xx-.035,xx+.035],[yy-se,yy-se],[.30,.36,.40],1.1),line([xx-.035,xx+.035],[yy+se,yy+se],[.30,.36,.40],1.1)])
    for si in range(3):children.append(line(np.array([1,2])+offsets[si],P[si,pi],line_rgb,.85,'o',7,point_rgb))
    children.append(text(1.5,1.08,labels[pi],14))
    children.append(text(.34,.5,'Conditional probability',11,90))
    pos=np.array([.11+(pi%2)*.48,.58-(pi//2)*.46,.37,.32])
    props=dict(Position=pos,Units='normalized',XLim=np.array([.55,2.45]),YLim=np.array([0.,1.]),XTick=np.array([1.,2.]),YTick=np.arange(0,1.01,.2),XTickLabel=np.array(['First Cue Instructed','First Cue Free'],dtype=object),FontName='Arial',FontSize=11.,Box='off',TickDir='out',Color=np.array([1.,1.,1.]),XColor=np.array([.25,.25,.25]),YColor=np.array([.25,.25,.25]),Visible='on',NextPlot='add')
    axes.append(hg('axes',props,children[::-1]))
container=hg('figure',dict(Color=np.array([1.,1.,1.]),Position=np.array([80.,80.,1100.,760.]),Units='pixels',Name='ChoiceAnalysis',NumberTitle='off',Visible='on',PaperPositionMode='auto'),axes[::-1])
sio.savemat(OUT/'Figure_ChoiceAnalysis.fig',{'hgS_070000':container},do_compression=True)
# 保存后重新读取并核验数值；FIG 树仅进行文件结构检查。
check=sio.loadmat(OUT/'Results_ChoiceAnalysis.mat',simplify_cells=True)['results'];assert np.array_equal(check['denominator'],D);assert np.allclose(check['P'],P,equal_nan=True)
fcheck=sio.loadmat(OUT/'Figure_ChoiceAnalysis.fig',simplify_cells=True);assert fcheck['hgS_070000']['type']=='figure'
assert np.all(N<=D);assert np.isfinite(P).all();assert len(rows)==24
print(framesout['GroupProbabilities'].to_string(index=False));print(statdf.to_string(index=False));print(framesout['PairedDifferences'].to_string(index=False))
