import scipy.io as s,io,numpy as np,warnings
from scipy.io.matlab._mio5 import varmats_from_mat
warnings.filterwarnings('ignore',category=s.matlab.MatReadWarning)
def cells(p):
 x=s.loadmat(p);b=x['__function_workspace__'].tobytes();f=io.BytesIO(b' '*116+b'\0'*8+b[:4]+b[8:]);n,z=next(iter(varmats_from_mat(f)));o=s.loadmat(z,struct_as_record=False)['__function_workspace__'].ravel()[0];return o.MCOS[0]['arr'].ravel()
if __name__=='__main__':
 a=cells('/workspace/ChoiceAnalysis/data/Subject3/Subject3_block1.mat')
 for i,v in enumerate(a):
  print(i,v.dtype,v.shape, str(v.ravel()[:4])[:180])

def decode(v):
 v=v.ravel(); n=int(v[2]*v[3]);lengths=v[4:4+n];raw=v[4+n:].tobytes().decode('utf-16-le');out=[];pos=0
 for k in lengths:out.append(raw[pos:pos+int(k)]);pos+=int(k)
 return out

def table(a,di,ni):
 out={}
 for name,v in zip(a[ni].ravel(),a[di].ravel()):
  key=str(name.ravel()[0]);r=v.ravel()
  if v.dtype==np.uint32 and len(r)==6 and r[0]==3707764736:
   oid=int(r[4]); vv=[z for z in a if z.dtype==np.uint64][oid-2 if oid<7 else oid-3];out[key]=decode(vv)
  else:out[key]=r
 return out
